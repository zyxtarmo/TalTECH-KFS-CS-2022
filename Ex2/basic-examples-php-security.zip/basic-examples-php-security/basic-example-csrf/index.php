<?php
session_start();
try {
    $PDO = new PDO("sqlite:./sampledb.sqlite");
    $users = $PDO->query("SELECT * from users")->fetchAll();
    $PDO = null;
} catch (PDOException $e) {
    print "Erreur !: " . $e->getMessage() . "<br/>";
    die();
}
require "view.php";
