Exemple basique d'utilisation d'une vulnérabilité CSRF dans un formulaire php

### Exemple de données à entrer dans l'input

- ```<p style="color:red">TEXTE MALVEILLANT</p>```
- ```<script>alert('Il y a une faille XSS')</script>```